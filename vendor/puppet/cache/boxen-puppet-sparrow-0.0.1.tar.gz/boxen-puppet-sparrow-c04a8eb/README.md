# Sparrow Puppet Module for Boxen

## Usage

```puppet
include sparrow
```