# ImageMagick Puppet Module for Boxen

Requires the following boxen modules:

* `boxen`
* `xquartz`

## Usage

```puppet
include imagemagick
```
