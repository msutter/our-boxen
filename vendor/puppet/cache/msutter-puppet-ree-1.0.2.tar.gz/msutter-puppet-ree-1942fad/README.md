# Ruby Enterprise Puppet Module for Rben under Boxen

Requires the following boxen modules:

* `boxen`
* `ruby`
* `xquartz`

## Usage

# install Ruby Enterprise 2012-01
require ree::1_8_7_2012_01
