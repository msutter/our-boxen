# Dropbox Puppet Module for Boxen

Requires the `boxen` puppet module.

## Usage

```puppet
include dropbox
```

## Developing

Write code.

Run `script/cibuild`.
