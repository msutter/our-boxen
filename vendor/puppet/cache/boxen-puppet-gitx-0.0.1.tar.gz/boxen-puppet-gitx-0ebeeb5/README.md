# GitX Puppet Module for Boxen

Requires the following boxen modules:

* `boxen`

## Usage

```puppet
include gitx
```
